#!/usr/bin/env python3
"""Генерує текстури, моделі, рецепти, loot tables, теги й переклади для 5 рівнів прискорювача.
Запуск: python3 tools/generate_assets.py  (потрібен Pillow)"""
import json, os, random
from PIL import Image

MOD = "selectionboost"
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources")
A = os.path.join(ROOT, "assets", MOD)
D = os.path.join(ROOT, "data", MOD)
random.seed(5)

def w(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    json.dump(obj, open(path, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

def n(base, s):
    return tuple(max(0, min(255, c + random.randint(-s, s))) for c in base) + (255,)

# рівень: (основний колір, колір рамки, колір "сот"/світла, англ., укр., рос.)
TIERS = [
    ((46, 110, 58),   (24, 60, 34),   (240, 190, 50),  "Basic",    "Базовий",    "Базовый"),
    ((40, 100, 150),  (20, 50, 85),   (170, 230, 255), "Improved", "Покращений", "Улучшенный"),
    ((110, 55, 160),  (60, 28, 95),   (235, 170, 255), "Advanced", "Просунутий", "Продвинутый"),
    ((190, 90, 40),   (100, 45, 20),  (255, 220, 120), "Perfect",  "Досконалий", "Совершенный"),
    ((200, 230, 240), (80, 100, 120), (255, 255, 255), "Photonic", "Фотонний",   "Фотонный"),
]

def name(t):
    return "breeding_booster" if t == 1 else f"breeding_booster_{t}"

def save(nm, fn):
    img = Image.new("RGBA", (16, 16))
    fn(img)
    p = os.path.join(A, "textures", "block", nm + ".png")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

for t, (main, dark, light, *_ ) in enumerate(TIERS, start=1):
    def base(img):
        for y in range(16):
            for x in range(16):
                img.putpixel((x, y), n(main, 8))
    def frame(img):
        for i in range(16):
            for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
                img.putpixel((x, y), n(dark, 6))
    def side(img):
        base(img); frame(img)
        for (cx, cy) in ((4, 4), (11, 4), (4, 9), (11, 9)):
            for dx, dy in ((0,0),(1,0),(-1,0),(0,1),(0,-1)):
                img.putpixel((cx + dx, cy + dy), n(light, 8))
        for i in range(t):                     # t крапок = рівень
            img.putpixel((3 + i * 2, 13), n(light, 4))
    def top(img):
        base(img); frame(img)
        for y in range(3, 13):
            for x in range(3, 13):
                if (x - 7.5) ** 2 + (y - 7.5) ** 2 < 22:
                    img.putpixel((x, y), n(light, 10))
        for y in range(6, 10):
            for x in range(6, 10):
                img.putpixel((x, y), n(dark, 6))
    def bottom(img):
        base(img); frame(img)
    save(name(t) + "_side", side); save(name(t) + "_top", top); save(name(t) + "_bottom", bottom)

    b = name(t)
    w(os.path.join(A, "models", "block", b + ".json"), {
        "parent": "minecraft:block/cube_bottom_top",
        "textures": {"top": f"{MOD}:block/{b}_top", "side": f"{MOD}:block/{b}_side", "bottom": f"{MOD}:block/{b}_bottom"}})
    w(os.path.join(A, "models", "item", b + ".json"), {"parent": f"{MOD}:block/{b}"})
    w(os.path.join(A, "blockstates", b + ".json"), {"variants": {"": {"model": f"{MOD}:block/{b}"}}})
    w(os.path.join(D, "loot_tables", "blocks", b + ".json"), {
        "type": "minecraft:block",
        "pools": [{"rolls": 1.0, "bonus_rolls": 0.0, "entries": [{"type": "minecraft:item", "name": f"{MOD}:{b}"}],
                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})

w(os.path.join(ROOT, "data", "minecraft", "tags", "blocks", "mineable", "pickaxe.json"),
  {"replace": False, "values": [f"{MOD}:{name(t)}" for t in range(1, len(TIERS) + 1)]})

# Рецепти. Рівень 1 з простих матеріалів; рівень N = попередній прискорювач у центрі + матеріали.
w(os.path.join(D, "recipes", name(1) + ".json"), {
    "type": "minecraft:crafting_shaped", "category": "misc",
    "pattern": ["RBR", "BDB", "RBR"],
    "key": {"R": {"item": "minecraft:redstone"}, "B": {"item": "minecraft:bone_meal"}, "D": {"item": "minecraft:diamond"}},
    "result": {"item": f"{MOD}:{name(1)}"}})
UPGRADES = {   # рівень: (кути, боки)
    2: ("minecraft:gold_ingot", "minecraft:bone_block"),
    3: ("minecraft:diamond", "minecraft:emerald"),
    4: ("minecraft:diamond_block", "minecraft:gold_block"),
    5: ("minecraft:netherite_ingot", "minecraft:nether_star"),
}
for t, (corner, edge) in UPGRADES.items():
    w(os.path.join(D, "recipes", name(t) + ".json"), {
        "type": "minecraft:crafting_shaped", "category": "misc",
        "pattern": ["CEC", "EXE", "CEC"],
        "key": {"C": {"item": corner}, "E": {"item": edge}, "X": {"item": f"{MOD}:{name(t - 1)}"}},
        "result": {"item": f"{MOD}:{name(t)}"}})

common = {
 "en_us": {"itemGroup.selectionboost": "Selection Boost",
           "message.selectionboost.status": "Tier %s: boosting %s blocks (radius %s, speed x%s)",
           "message.selectionboost.scan_none": "No Industrial Upgrade blocks within 8 blocks of you",
           "message.selectionboost.scan_header": "Industrial Upgrade blocks nearby (id, count, tick type):",
           "message.selectionboost.scan_line": "%s x%s [%s, %s]"},
 "uk_ua": {"itemGroup.selectionboost": "Selection Boost",
           "message.selectionboost.status": "Рівень %s: прискорюється блоків %s (радіус %s, швидкість x%s)",
           "message.selectionboost.scan_none": "Блоків Industrial Upgrade у радіусі 8 блоків немає",
           "message.selectionboost.scan_header": "Блоки Industrial Upgrade поруч (ID, кількість, тип тіку):",
           "message.selectionboost.scan_line": "%s x%s [%s, %s]"},
 "ru_ru": {"itemGroup.selectionboost": "Selection Boost",
           "message.selectionboost.status": "Уровень %s: ускоряется блоков %s (радиус %s, скорость x%s)",
           "message.selectionboost.scan_none": "Блоков Industrial Upgrade в радиусе 8 блоков нет",
           "message.selectionboost.scan_header": "Блоки Industrial Upgrade рядом (ID, количество, тип тика):",
           "message.selectionboost.scan_line": "%s x%s [%s, %s]"},
}
base_names = {"en_us": "Breeding Booster", "uk_ua": "Прискорювач селекції", "ru_ru": "Ускоритель селекции"}
idx = {"en_us": 3, "uk_ua": 4, "ru_ru": 5}
for code, d in common.items():
    for t, tier in enumerate(TIERS, start=1):
        d[f"block.{MOD}.{name(t)}"] = f"{base_names[code]}: {tier[idx[code]]} ({'I' * t if t < 4 else ['IV','V'][t-4]})"
    w(os.path.join(A, "lang", code + ".json"), d)
print("Готово")
