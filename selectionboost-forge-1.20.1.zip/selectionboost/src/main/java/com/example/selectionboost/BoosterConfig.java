package com.example.selectionboost;

import java.util.List;

import net.minecraftforge.common.ForgeConfigSpec;

/** Налаштування (файл config/selectionboost-common.toml). */
public class BoosterConfig {
    public static final int TIERS = 5;
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue[] RADIUS = new ForgeConfigSpec.IntValue[TIERS];
    public static final ForgeConfigSpec.IntValue[] EXTRA_TICKS = new ForgeConfigSpec.IntValue[TIERS];
    public static final ForgeConfigSpec.IntValue RESCAN_INTERVAL;
    public static final ForgeConfigSpec.IntValue MAX_TARGETS;
    public static final ForgeConfigSpec.ConfigValue<List<? extends String>> FILTERS;

    // Значення за замовчуванням для рівнів 1..5
    private static final int[] DEFAULT_RADIUS = {4, 8, 12, 16, 24};
    private static final int[] DEFAULT_EXTRA = {2, 4, 8, 16, 32};

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        for (int i = 0; i < TIERS; i++) {
            b.push("tier" + (i + 1));
            RADIUS[i] = b.comment("Радіус дії (куб навколо прискорювача), блоків.")
                    .defineInRange("radius", DEFAULT_RADIUS[i], 1, 32);
            EXTRA_TICKS[i] = b.comment("Скільки ДОДАТКОВИХ тактів роботи отримує кожен блок за кожен такт гри. N = у (N+1) разів швидше. 0 = вимкнено.")
                    .defineInRange("extraTicksPerTick", DEFAULT_EXTRA[i], 0, 128);
            b.pop();
        }
        RESCAN_INTERVAL = b.comment("Як часто (у тактах) прискорювач заново шукає блоки навколо.")
                .defineInRange("rescanIntervalTicks", 100, 20, 1200);
        MAX_TARGETS = b.comment("Максимум блоків, які прискорює один прискорювач (захист від лагів).")
                .defineInRange("maxTargets", 256, 1, 4096);
        FILTERS = b.comment("Які блоки прискорювати. Запис = початок ID блока 'мод:шлях'.",
                        "Приклад: \"industrialupgrade:crop/\" прискорює все з категорії crop/.",
                        "Додайте \"industrialupgrade:basemachine3/\", щоб прискорити й машини (вони тоді споживатимуть більше енергії!).",
                        "ID блоків можна подивитись командою /selectionboost scan.")
                .defineList("blockFilters", List.of("industrialupgrade:crop/", "industrialupgrade:apiary/"), o -> o instanceof String);
        SPEC = b.build();
    }

    public static boolean matches(String id) {
        for (String f : FILTERS.get()) {
            if (id.startsWith(f)) {
                return true;
            }
        }
        return false;
    }
}
