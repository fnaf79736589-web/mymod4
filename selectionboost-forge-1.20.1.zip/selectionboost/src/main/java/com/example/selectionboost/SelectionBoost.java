package com.example.selectionboost;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(SelectionBoost.MODID)
public class SelectionBoost {
    public static final String MODID = "selectionboost";
    public static final int TIERS = BoosterConfig.TIERS;

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final List<RegistryObject<Block>> BOOSTERS = new ArrayList<>();
    public static final List<RegistryObject<Item>> BOOSTER_ITEMS = new ArrayList<>();

    static {
        for (int t = 1; t <= TIERS; t++) {
            final int tier = t;
            // рівень 1 зберігає старий ID breeding_booster, решта: breeding_booster_2 ... _5
            String name = tier == 1 ? "breeding_booster" : "breeding_booster_" + tier;
            RegistryObject<Block> block = BLOCKS.register(name,
                    () -> new BoosterBlock(BlockBehaviour.Properties.of().strength(2.5F).sound(SoundType.METAL), tier));
            BOOSTERS.add(block);
            BOOSTER_ITEMS.add(ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties())));
        }
    }

    /** Один тип блок-сутності для всіх рівнів. */
    public static final RegistryObject<BlockEntityType<BoosterBlockEntity>> BOOSTER_BE = BLOCK_ENTITIES.register("breeding_booster",
            () -> BlockEntityType.Builder.of(BoosterBlockEntity::new,
                    BOOSTERS.stream().map(RegistryObject::get).toArray(Block[]::new)).build(null));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.selectionboost"))
                    .icon(() -> new ItemStack(BOOSTER_ITEMS.get(TIERS - 1).get()))
                    .displayItems((params, out) -> BOOSTER_ITEMS.forEach(i -> out.accept(i.get())))
                    .build());

    public SelectionBoost() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
        TABS.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, BoosterConfig.SPEC);
    }
}
