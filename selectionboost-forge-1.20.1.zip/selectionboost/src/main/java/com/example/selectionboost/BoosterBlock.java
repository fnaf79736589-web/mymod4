package com.example.selectionboost;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public class BoosterBlock extends BaseEntityBlock {
    /** Рівень прискорювача: 1..5. */
    public final int tier;

    public BoosterBlock(Properties properties, int tier) {
        super(properties);
        this.tier = tier;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new BoosterBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return level.isClientSide ? null
                : createTickerHelper(type, SelectionBoost.BOOSTER_BE.get(), BoosterBlockEntity::serverTick);
    }

    /** ПКМ показує рівень і скільки блоків зараз прискорюється. */
    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof BoosterBlockEntity be) {
            player.displayClientMessage(Component.translatable("message.selectionboost.status",
                    tier, be.getTargetCount(), BoosterConfig.RADIUS[tier - 1].get(), BoosterConfig.EXTRA_TICKS[tier - 1].get() + 1), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
