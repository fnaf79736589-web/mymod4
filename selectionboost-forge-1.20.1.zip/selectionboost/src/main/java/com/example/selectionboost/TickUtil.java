package com.example.selectionboost;

import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

public class TickUtil {
    /** Повертає "тікер" блок-сутності (або null, якщо блок не тікається звичайним способом). */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static BlockEntityTicker ticker(Level level, BlockState state, BlockEntity be) {
        return state.getTicker(level, (BlockEntityType) be.getType());
    }
}
